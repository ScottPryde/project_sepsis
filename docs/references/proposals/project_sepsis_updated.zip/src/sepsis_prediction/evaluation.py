"""Held-out comparison of models for effective prediction.

Everything here is computed from ``test_predictions.csv`` so that every model
is judged on exactly the same patients. The analysis answers four questions:

1. Discrimination: how well does each model rank patients who later develop
   sepsis above those who do not (AUROC, AUPRC), with paired bootstrap 95% CIs?
2. Distinguishability: is each model's advantage over the others larger than
   resampling noise (paired bootstrap difference against the top model)?
3. Operating point: at a common sensitivity, how many alerts does each model
   raise, how many are true, and how many cases are missed per 100 patients?
4. Calibration and clinical utility: do probabilities mean what they say, and
   does acting on them beat treat-all / treat-none (decision-curve net benefit)?
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, brier_score_loss, roc_auc_score

MODEL_LABELS = {
    "logistic_regression": "Logistic Regression",
    "random_forest": "Random Forest",
    "xgboost": "XGBoost",
    "cnn_1d": "1D CNN",
}
MODEL_COLORS = {
    "logistic_regression": "#167b73",
    "random_forest": "#477d9e",
    "xgboost": "#d89a38",
    "cnn_1d": "#c45042",
}
TARGET_SENSITIVITY = 0.80
NET_BENEFIT_THRESHOLDS = np.round(np.arange(0.01, 0.51, 0.01), 2)


def model_label(name: str) -> str:
    return MODEL_LABELS.get(name, name.replace("_", " ").title())


def model_color(name: str) -> str:
    return MODEL_COLORS.get(name, "#536966")


def _model_names(predictions: pd.DataFrame) -> list[str]:
    return [
        column.removesuffix("_probability")
        for column in predictions.columns
        if column.endswith("_probability")
    ]


def _safe_auc(y: np.ndarray, p: np.ndarray) -> float:
    return float(roc_auc_score(y, p)) if np.unique(y).size == 2 else np.nan


def _safe_ap(y: np.ndarray, p: np.ndarray) -> float:
    return float(average_precision_score(y, p)) if np.unique(y).size == 2 else np.nan


def _ci(values: np.ndarray) -> tuple[float | None, float | None]:
    values = values[np.isfinite(values)]
    if values.size < 20:
        return None, None
    low, high = np.percentile(values, [2.5, 97.5])
    return float(low), float(high)


def _none_if_nan(value: float) -> float | None:
    return None if value is None or not np.isfinite(value) else float(value)


def operating_point(y: np.ndarray, p: np.ndarray, target_sensitivity: float) -> dict[str, Any]:
    """Highest threshold whose sensitivity reaches the target on these patients.

    The threshold is chosen on the evaluation patients themselves, so this is a
    descriptive comparison of models at matched sensitivity, not an estimate of
    deployed performance. A validation split is required for the latter.
    """
    positives = int(y.sum())
    n = int(y.size)
    if positives == 0 or positives == n:
        return {"threshold": None}
    for threshold in np.unique(p)[::-1]:
        flagged = p >= threshold
        true_positive = int((flagged & (y == 1)).sum())
        if true_positive / positives >= target_sensitivity:
            false_positive = int((flagged & (y == 0)).sum())
            negatives = n - positives
            alerts = int(flagged.sum())
            ppv = true_positive / alerts if alerts else np.nan
            return {
                "threshold": float(threshold),
                "sensitivity": true_positive / positives,
                "specificity": (negatives - false_positive) / negatives if negatives else np.nan,
                "ppv": ppv,
                "alerts_per_100": 100 * alerts / n,
                "true_alerts_per_100": 100 * true_positive / n,
                "missed_per_100": 100 * (positives - true_positive) / n,
                "alerts_per_true_case": 1 / ppv if ppv and np.isfinite(ppv) else np.nan,
            }
    return {"threshold": None}


def calibration_summary(y: np.ndarray, p: np.ndarray) -> dict[str, float | None]:
    """Calibration-in-the-large, logistic calibration slope, and 10-bin ECE."""
    clipped = np.clip(p, 1e-6, 1 - 1e-6)
    logit = np.log(clipped / (1 - clipped))
    slope = intercept = np.nan
    if np.unique(y).size == 2 and np.std(logit) > 0:
        from sklearn.linear_model import LogisticRegression

        fitted = LogisticRegression(C=1e6, max_iter=1000).fit(logit[:, None], y)
        slope = float(fitted.coef_[0][0])
        intercept = float(fitted.intercept_[0])
    edges = np.linspace(0, 1, 11)
    bins = np.clip(np.digitize(p, edges[1:-1]), 0, 9)
    ece = 0.0
    for b in range(10):
        mask = bins == b
        if mask.any():
            ece += mask.mean() * abs(p[mask].mean() - y[mask].mean())
    return {
        "mean_predicted": float(p.mean()),
        "observed_rate": float(y.mean()),
        "calibration_slope": _none_if_nan(slope),
        "calibration_intercept": _none_if_nan(intercept),
        "ece_10_bin": float(ece),
    }


def net_benefit(y: np.ndarray, p: np.ndarray, thresholds: np.ndarray) -> np.ndarray:
    n = y.size
    out = []
    for t in thresholds:
        flagged = p >= t
        tp = np.sum(flagged & (y == 1))
        fp = np.sum(flagged & (y == 0))
        out.append(tp / n - fp / n * (t / (1 - t)))
    return np.asarray(out)


def compare_models(
    output_dir: str | Path,
    *,
    n_bootstrap: int = 1000,
    random_state: int = 42,
    target_sensitivity: float = TARGET_SENSITIVITY,
) -> dict[str, Any]:
    """Compute the effective-prediction comparison and write JSON/CSV/PNG outputs."""
    output = Path(output_dir)
    predictions = pd.read_csv(output / "test_predictions.csv")
    names = _model_names(predictions)
    y = predictions["y_true"].to_numpy(dtype=int)
    probs = {name: predictions[f"{name}_probability"].to_numpy(dtype=float) for name in names}
    both_classes = np.unique(y).size == 2

    rng = np.random.default_rng(random_state)
    n = y.size
    boot_auc = {name: np.full(n_bootstrap, np.nan) for name in names}
    boot_ap = {name: np.full(n_bootstrap, np.nan) for name in names}
    boot_brier = {name: np.full(n_bootstrap, np.nan) for name in names}
    if both_classes:
        for b in range(n_bootstrap):
            idx = rng.integers(0, n, n)
            yb = y[idx]
            if np.unique(yb).size < 2:
                continue
            for name in names:
                pb = probs[name][idx]
                boot_auc[name][b] = _safe_auc(yb, pb)
                boot_ap[name][b] = _safe_ap(yb, pb)
                boot_brier[name][b] = brier_score_loss(yb, pb)

    rows: list[dict[str, Any]] = []
    for name in names:
        p = probs[name]
        auc_low, auc_high = _ci(boot_auc[name])
        ap_low, ap_high = _ci(boot_ap[name])
        brier_low, brier_high = _ci(boot_brier[name])
        rows.append({
            "model": name,
            "label": model_label(name),
            "auroc": _none_if_nan(_safe_auc(y, p)),
            "auroc_ci": [auc_low, auc_high],
            "auprc": _none_if_nan(_safe_ap(y, p)),
            "auprc_ci": [ap_low, ap_high],
            "auprc_lift": _none_if_nan(_safe_ap(y, p) / y.mean()) if y.mean() > 0 else None,
            "brier": float(brier_score_loss(y, p)),
            "brier_ci": [brier_low, brier_high],
            "operating_point": {k: _none_if_nan(v) if isinstance(v, float) else v
                                for k, v in operating_point(y, p, target_sensitivity).items()},
            "calibration": calibration_summary(y, p),
        })

    # Rank by AUPRC (primary under class imbalance), AUROC as tie-break.
    rows.sort(key=lambda r: (r["auprc"] if r["auprc"] is not None else -1,
                             r["auroc"] if r["auroc"] is not None else -1), reverse=True)
    for rank, row in enumerate(rows, start=1):
        row["rank"] = rank

    best = rows[0]["model"] if rows else None
    for row in rows:
        name = row["model"]
        if name == best or not both_classes:
            row["vs_best"] = None
            continue
        diff_ap = boot_ap[best] - boot_ap[name]
        diff_auc = boot_auc[best] - boot_auc[name]
        ap_low, ap_high = _ci(diff_ap)
        auc_low, auc_high = _ci(diff_auc)
        finite = diff_ap[np.isfinite(diff_ap)]
        row["vs_best"] = {
            "best_model": best,
            "auprc_difference": _none_if_nan(rows[0]["auprc"] - row["auprc"])
            if rows[0]["auprc"] is not None and row["auprc"] is not None else None,
            "auprc_difference_ci": [ap_low, ap_high],
            "auroc_difference_ci": [auc_low, auc_high],
            "share_of_resamples_best_wins": float((finite > 0).mean()) if finite.size else None,
            "distinguishable": bool(ap_low is not None and ap_low > 0),
            "auroc_distinguishable": bool(auc_low is not None and auc_low > 0),
        }

    thresholds = NET_BENEFIT_THRESHOLDS
    prevalence = float(y.mean()) if n else 0.0
    decision = {
        "thresholds": thresholds.tolist(),
        "treat_all": (prevalence - (1 - prevalence) * thresholds / (1 - thresholds)).tolist(),
        "models": {name: net_benefit(y, probs[name], thresholds).tolist() for name in names},
    }

    result = {
        "n_test": int(n),
        "positives": int(y.sum()),
        "prevalence": prevalence,
        "n_bootstrap": n_bootstrap,
        "bootstrap_seed": random_state,
        "target_sensitivity": target_sensitivity,
        "ranking_rule": "AUPRC (primary, class-imbalance aware), AUROC tie-break",
        "best_model": best,
        "models": rows,
        "decision_curve": decision,
    }
    (output / "model_evaluation.json").write_text(
        json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8",
    )
    _flat_table(rows).to_csv(output / "model_ranking.csv", index=False, float_format="%.6g")
    _plot_calibration(output, y, probs)
    _plot_decision_curve(output, decision)
    _plot_forest(output, rows)
    return result


def _flat_table(rows: list[dict[str, Any]]) -> pd.DataFrame:
    flat = []
    for row in rows:
        op = row["operating_point"]
        cal = row["calibration"]
        flat.append({
            "rank": row["rank"],
            "model": row["model"],
            "auprc": row["auprc"],
            "auprc_ci_low": row["auprc_ci"][0],
            "auprc_ci_high": row["auprc_ci"][1],
            "auroc": row["auroc"],
            "auroc_ci_low": row["auroc_ci"][0],
            "auroc_ci_high": row["auroc_ci"][1],
            "brier": row["brier"],
            "calibration_slope": cal["calibration_slope"],
            "ece_10_bin": cal["ece_10_bin"],
            "op_threshold": op.get("threshold"),
            "op_specificity": op.get("specificity"),
            "op_ppv": op.get("ppv"),
            "op_alerts_per_100": op.get("alerts_per_100"),
            "op_alerts_per_true_case": op.get("alerts_per_true_case"),
        })
    return pd.DataFrame(flat)


def _plot_calibration(output: Path, y: np.ndarray, probs: dict[str, np.ndarray]) -> None:
    figure, axis = plt.subplots(figsize=(5.6, 4.6))
    axis.plot([0, 1], [0, 1], color="#777777", linestyle="--", linewidth=1, label="Perfect calibration")
    for name, p in probs.items():
        quantiles = np.unique(np.quantile(p, np.linspace(0, 1, 11)))
        if quantiles.size < 2:
            continue
        bins = np.clip(np.digitize(p, quantiles[1:-1]), 0, quantiles.size - 2)
        xs, ys = [], []
        for b in range(quantiles.size - 1):
            mask = bins == b
            if mask.sum() >= 1:
                xs.append(p[mask].mean())
                ys.append(y[mask].mean())
        axis.plot(xs, ys, marker="o", markersize=4, linewidth=1.6, color=model_color(name), label=model_label(name))
    axis.set(xlim=(0, 1), ylim=(0, 1), xlabel="Mean predicted risk (decile)", ylabel="Observed sepsis rate",
             title="Calibration")
    axis.legend(frameon=False, fontsize=8, loc="upper left")
    figure.tight_layout()
    figure.savefig(output / "calibration.png", dpi=160)
    plt.close(figure)


def _plot_decision_curve(output: Path, decision: dict[str, Any]) -> None:
    thresholds = np.asarray(decision["thresholds"])
    figure, axis = plt.subplots(figsize=(5.6, 4.6))
    axis.plot(thresholds, decision["treat_all"], color="#999999", linewidth=1.2, label="Alert everyone")
    axis.axhline(0, color="#444444", linewidth=1, label="Alert no one")
    top = 0.0
    for name, values in decision["models"].items():
        axis.plot(thresholds, values, linewidth=1.8, color=model_color(name), label=model_label(name))
        top = max(top, max(values))
    top = max(top, max(decision["treat_all"]), 0.01)
    axis.set(xlim=(0, thresholds.max()), ylim=(-top * 0.25, top * 1.15), xlabel="Risk threshold for alerting",
             ylabel="Net benefit", title="Decision curve")
    axis.legend(frameon=False, fontsize=8)
    figure.tight_layout()
    figure.savefig(output / "decision_curve.png", dpi=160)
    plt.close(figure)


def _plot_forest(output: Path, rows: list[dict[str, Any]]) -> None:
    figure, axes = plt.subplots(1, 2, figsize=(10, 0.6 * max(len(rows), 2) + 1.6), sharey=True)
    labels = [model_label(r["model"]) for r in rows][::-1]
    for axis, key, title in ((axes[0], "auprc", "AUPRC (95% CI)"), (axes[1], "auroc", "AUROC (95% CI)")):
        for position, row in enumerate(rows[::-1]):
            value = row[key]
            low, high = row[f"{key}_ci"]
            if value is None:
                continue
            color = model_color(row["model"])
            if low is not None and high is not None:
                axis.plot([low, high], [position, position], color=color, linewidth=2.4)
            axis.plot(value, position, "o", color=color, markersize=7)
        axis.set_title(title, fontsize=11)
        axis.set_xlim(0, 1)
        axis.grid(axis="x", color="#e3e7e4")
    axes[0].set_yticks(range(len(labels)), labels)
    figure.tight_layout()
    figure.savefig(output / "model_forest.png", dpi=160)
    plt.close(figure)
