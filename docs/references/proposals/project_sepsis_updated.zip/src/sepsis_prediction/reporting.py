"""Held-out model comparison tables and discrimination plots."""

from __future__ import annotations

import base64
import html
import json
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import precision_recall_curve, roc_curve

from sepsis_prediction.data import KNOWN_CLINICAL_COLUMNS, TARGET_COLUMN, PatientRecord
from sepsis_prediction.evaluation import compare_models, model_color, model_label


def write_model_comparison(output_dir: str | Path) -> pd.DataFrame:
    """Write metric table and ROC/PR plots from saved test predictions."""
    output = Path(output_dir)
    predictions = pd.read_csv(output / "test_predictions.csv")
    model_names = [
        column.removesuffix("_probability")
        for column in predictions.columns
        if column.endswith("_probability")
    ]
    if not model_names:
        raise ValueError("No model probabilities found in test_predictions.csv")

    table = pd.DataFrame([
        {
            "model": model_name,
            "auroc": _metric(output, model_name, "auroc"),
            "auprc_average_precision": _metric(output, model_name, "auprc_average_precision"),
            "sensitivity_recall": _metric(output, model_name, "sensitivity_recall"),
            "specificity": _metric(output, model_name, "specificity"),
            "f1": _metric(output, model_name, "f1"),
            "brier_score": _metric(output, model_name, "brier_score"),
        }
        for model_name in model_names
    ])
    table.to_csv(output / "model_comparison.csv", index=False, float_format="%.8g")

    labels = predictions["y_true"].to_numpy(dtype=int)
    has_both_classes = pd.Series(labels).nunique() == 2
    figure, axes = plt.subplots(1, 2, figsize=(11, 4.5))
    if has_both_classes:
        for model_name in model_names:
            probabilities = predictions[f"{model_name}_probability"].to_numpy()
            false_positive_rate, true_positive_rate, _ = roc_curve(labels, probabilities)
            precision, recall, _ = precision_recall_curve(labels, probabilities)
            axes[0].plot(false_positive_rate, true_positive_rate, label=model_label(model_name),
                         color=model_color(model_name), linewidth=1.6)
            axes[1].plot(recall, precision, label=model_label(model_name),
                         color=model_color(model_name), linewidth=1.6)
        axes[0].plot([0, 1], [0, 1], color="#777777", linestyle="--", linewidth=1)
        axes[0].set(xlabel="False positive rate", ylabel="True positive rate", title="ROC")
        axes[1].axhline(labels.mean(), color="#777777", linestyle="--", linewidth=1, label="Base rate")
        axes[1].set(xlabel="Recall", ylabel="Precision", title="Precision-recall")
        axes[0].legend(loc="lower right", frameon=False)
        axes[1].legend(loc="best", frameon=False)
    else:
        axes[0].text(0.5, 0.5, "ROC undefined: test set has one class", ha="center", va="center")
        axes[1].text(0.5, 0.5, "PR curve limited: test set has one class", ha="center", va="center")
        axes[0].set_axis_off()
        axes[1].set_axis_off()
    figure.tight_layout()
    figure.savefig(output / "model_curves.png", dpi=160)
    plt.close(figure)
    config = _read_json(output / "run_config.json", {})
    compare_models(output, random_state=int(config.get("random_state", 42)))
    return table


def _metric(output: Path, model_name: str, metric: str) -> float | None:
    import json

    content = json.loads((output / "metrics.json").read_text(encoding="utf-8"))
    value = content[model_name][metric]
    return float(value) if value is not None else None


def write_html_report(
    output_dir: str | Path,
    *,
    records: list[PatientRecord] | None = None,
    features: pd.DataFrame | None = None,
    title: str = "Early Sepsis Prediction | Experiment Report",
) -> Path:
    """Generate a self-contained report from available experiment artifacts."""
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    metrics = _read_json(output / "metrics.json", {})
    cohort = _read_json(output / "cohort_summary.json", {})
    dataset = _read_json(output / "dataset_summary.json", {})
    config = _read_json(output / "run_config.json", {})
    comparison = pd.read_csv(output / "model_comparison.csv") if (output / "model_comparison.csv").exists() else pd.DataFrame()

    sample_html = _render_sample(records, features)
    metrics_html = _render_metrics(metrics)
    comparison_html = _render_comparison(comparison)
    cohort_html = _render_cohort(cohort, dataset)
    feature_html = _render_feature_sample(features)
    charts_html = _render_charts(output, metrics)
    diagrams_html = _render_diagrams(config)
    evaluation = _read_json(output / "model_evaluation.json", {})
    methodology_html = _render_methodology(config, cohort, evaluation, features)
    effective_html = _render_effective(output, evaluation)
    generated_at = pd.Timestamp.now(tz="UTC").strftime("%Y-%m-%d %H:%M UTC")

    document = f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="color-scheme" content="light">
<title>{html.escape(title)}</title>
<style>
:root {{ color-scheme: light; --ink:#1c2727; --muted:#52605f; --line:#d8dfdc; --paper:#f4f5f0; --white:#fff; --teal:#167b73; --coral:#c45042; --gold:#d89a38; --blue:#477d9e; --font: "Aptos", "Segoe UI", sans-serif; }}
* {{ box-sizing:border-box; }} body {{ margin:0; color:var(--ink); background:var(--paper); font-family:var(--font); line-height:1.5; }}
.masthead {{ padding:26px max(24px, calc((100vw - 1180px)/2)); color:#f8f7ef; background:linear-gradient(110deg,#123d3a,#1a6258 62%,#247c6c); border-bottom:5px solid var(--gold); }}
.eyebrow {{ text-transform:uppercase; font-size:12px; font-weight:700; letter-spacing:.12em; color:#bfe2d6; }} h1 {{ max-width:900px; margin:10px 0 6px; font-size:42px; line-height:1.08; }}
.masthead p {{ max-width:850px; margin:8px 0 0; color:#e1eee9; }} main {{ max-width:1180px; margin:0 auto; padding:24px; }}
.notice {{ padding:13px 16px; margin-bottom:24px; border-left:4px solid var(--coral); background:#fff4ef; color:#542d28; }}
section {{ padding:22px 0 26px; border-top:1px solid var(--line); }} h2 {{ margin:0 0 14px; font-size:22px; }} h3 {{ margin:0 0 10px; font-size:16px; }}
.summary-grid {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(150px,1fr)); gap:10px; margin-bottom:20px; }}
.stat {{ min-height:92px; padding:14px 16px; background:var(--white); border-top:3px solid var(--teal); }} .stat strong {{ display:block; font-size:26px; line-height:1.15; }} .stat span {{ color:var(--muted); font-size:13px; }}
.chart-grid {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(min(100%,430px),1fr)); gap:16px; }}
.panel {{ min-width:0; padding:16px; background:var(--white); border:1px solid var(--line); }} .panel img {{ display:block; width:100%; height:auto; }}
.table-wrap {{ width:100%; overflow-x:auto; border:1px solid var(--line); background:var(--white); }} table {{ width:100%; border-collapse:collapse; font-size:13px; white-space:nowrap; }} th,td {{ padding:9px 11px; text-align:left; border-bottom:1px solid #e6eae7; }} th {{ position:sticky; top:0; color:#35504d; background:#edf2ee; font-weight:700; }} tbody tr:nth-child(even) {{ background:#f8faf8; }}
.diagram {{ overflow-x:auto; padding:12px; background:#fff; border:1px solid var(--line); }} svg {{ display:block; max-width:100%; height:auto; }} .diagram-label {{ color:var(--muted); font-size:13px; margin:0 0 8px; }}
.muted {{ color:var(--muted); font-size:12px; }} .prose {{ max-width:78ch; }} .prose p {{ margin:0 0 12px; }} .prose ul {{ margin:0 0 12px; padding-left:20px; }} .prose li {{ margin-bottom:5px; }}
.verdict {{ padding:16px 18px; margin-bottom:18px; background:var(--white); border-left:5px solid var(--teal); }} .verdict p {{ margin:0 0 6px; max-width:90ch; }} .verdict .caution {{ color:var(--coral); }}
.rank-table td:first-child {{ font-weight:700; }} .rank-table td:last-child {{ white-space:normal; min-width:170px; }} .panel.wide {{ grid-column:1 / -1; }} .panel.wide img {{ max-width:860px; }} .rank-table th {{ white-space:normal; vertical-align:bottom; }} .swatch {{ display:inline-block; width:10px; height:10px; margin-right:7px; border-radius:2px; vertical-align:middle; }}
details.detail {{ margin:18px 0; padding:12px 16px; background:var(--white); border:1px solid var(--line); }} details.detail summary {{ cursor:pointer; font-weight:700; }} details.detail[open] summary {{ margin-bottom:12px; }}
.method-grid.prose {{ max-width:none; }} .method-grid {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(min(100%,420px),1fr)); gap:16px 28px; }}
.empty {{ color:var(--muted); padding:12px 0; }} .footer {{ border-top:1px solid var(--line); padding:18px 0; color:var(--muted); font-size:12px; }}
@media(max-width:600px) {{ main {{ padding:18px; }} .masthead {{ padding:22px 18px; }} h1 {{ font-size:30px; }} .panel {{ padding:12px; }} th,td {{ padding:8px; }} }}
@media print {{ body {{ background:white; }} .masthead {{ print-color-adjust:exact; }} section {{ break-inside:avoid; }} }}
</style>
</head>
<body>
<header class="masthead"><div class="eyebrow">PhysioNet 2019 · Applied ML study</div><h1>{html.escape(title)}</h1><p>Patient-level early-prediction experiment · six-hour look-back · generated {generated_at}</p></header>
<main>
<div class="notice"><strong>Research use only.</strong> Retrospective modelling results are not clinically validated. This report may contain patient-derived clinical values; handle and share it according to the dataset terms and your institution's privacy requirements.</div>
{cohort_html}
{methodology_html}
<section><h2>Model results</h2>{effective_html}<details class="detail"><summary>Per-model metrics at the fixed {html.escape(str(config.get("threshold", 0.5)))} threshold</summary><p class="diagram-label">These depend on each model's class weighting, so they are not a like-for-like comparison. Use the matched-sensitivity table above to compare models.</p>{metrics_html}{comparison_html}</details><div class="chart-grid">{charts_html}</div></section>
<section><h2>Pipeline and data lineage</h2>{diagrams_html}</section>
<section><h2>Sample of source observations</h2><p class="diagram-label">First six rows only, matching the model input window; identifiers are replaced with report-local labels.</p>{sample_html}</section>
<section><h2>Sample engineered inputs</h2><p class="diagram-label">Descriptive feature values from the same fixed look-back, where available.</p>{feature_html}</section>
<div class="footer">Prediction design: input rows 0–5; outcome is any positive SepsisLabel from row 6 onward. Patients positive in the look-back or without outcome follow-up are excluded. IDs and SepsisLabel are not model inputs; ICULOS is excluded.</div>
</main>
</body></html>"""
    report_path = output / "report.html"
    report_path.write_text(document, encoding="utf-8")
    return report_path


def _read_json(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    return json.loads(path.read_text(encoding="utf-8"))


def _render_metrics(metrics: dict[str, dict[str, Any]]) -> str:
    if not metrics:
        return '<p class="empty">No trained model results are present yet. Run the training command to populate this section.</p>'
    metric_labels = {
        "auroc": "AUROC", "auprc_average_precision": "AUPRC", "sensitivity_recall": "Sensitivity",
        "specificity": "Specificity", "precision": "Precision", "f1": "F1", "brier_score": "Brier",
    }
    items = []
    for name, values in metrics.items():
        count = values.get("n", "—")
        items.append(f'<div class="stat"><strong>{html.escape(str(count))}</strong><span>{html.escape(name)} · test patients</span></div>')
        for key, label in metric_labels.items():
            value = values.get(key)
            shown = "—" if value is None else f"{float(value):.3f}"
            items.append(f'<div class="stat"><strong>{shown}</strong><span>{html.escape(name)} · {label}</span></div>')
    return '<div class="summary-grid">' + "".join(items) + "</div>"


def _render_comparison(table: pd.DataFrame) -> str:
    if table.empty:
        return ""
    rendered = table.to_html(
        index=False,
        border=0,
        classes="results-table",
        na_rep="—",
        float_format=lambda value: f"{value:.3f}",
    )
    return '<h3>Held-out comparison</h3><div class="table-wrap">' + rendered + '</div>'


def _render_cohort(cohort: dict[str, Any], dataset: dict[str, Any]) -> str:
    values = []
    if cohort:
        values.extend([
            ("Eligible patients", cohort.get("eligible_patients", "—")),
            ("Positive outcomes", cohort.get("positive_outcomes", "—")),
        ])
        for key, value in cohort.get("exclusions", {}).items():
            values.append((f"Excluded · {key.replace('_', ' ')}", value))
    if dataset:
        values.extend([
            ("Source patients", dataset.get("patient_count", "—")),
            ("Hourly observations", dataset.get("hourly_observation_count", "—")),
            ("Positive row-label fraction", _format_value(dataset.get("positive_label_fraction"))),
        ])
    if not values:
        return ""
    cards = "".join(
        f'<div class="stat"><strong>{html.escape(str(value))}</strong><span>{html.escape(label)}</span></div>'
        for label, value in values
    )
    return f'<section><h2>Study snapshot</h2><div class="summary-grid">{cards}</div></section>'


def _render_charts(output: Path, metrics: dict[str, dict[str, Any]]) -> str:
    sections = []
    curve_path = output / "model_curves.png"
    if curve_path.exists():
        encoded = base64.b64encode(curve_path.read_bytes()).decode("ascii")
        sections.append(f'<div class="panel"><h3>Discrimination curves</h3><img alt="ROC and precision-recall curves" src="data:image/png;base64,{encoded}"></div>')
    for filename, heading, alt in (
        ("missingness.png", "Missingness by variable", "Clinical variable missingness chart"),
        ("record_lengths.png", "Patient record lengths", "Patient record length histogram"),
        ("labels_by_hour.png", "Label prevalence by hour", "Sepsis label fraction by hour index"),
    ):
        image_path = output / filename
        if image_path.exists():
            encoded = base64.b64encode(image_path.read_bytes()).decode("ascii")
            sections.append(f'<div class="panel"><h3>{heading}</h3><img alt="{alt}" src="data:image/png;base64,{encoded}"></div>')
    if not sections:
        return '<div class="panel empty">Run an experiment to generate result charts.</div>'
    return '<style>.metric-header,.metric-row{display:grid;grid-template-columns:130px repeat(5,minmax(62px,1fr));gap:8px;align-items:center;margin:9px 0;font-size:11px}.metric-header{color:#52605f;text-transform:capitalize}.metric-row strong{font-size:12px}.bar-track{height:10px;background:#e9eeeb;border-radius:2px;overflow:hidden}.bar-track span{display:block;height:100%;border-radius:2px}</style>' + "".join(sections)


def _fmt(value: Any, digits: int = 3) -> str:
    if value is None:
        return "—"
    try:
        number = float(value)
    except (TypeError, ValueError):
        return "—"
    if not np.isfinite(number):
        return "—"
    return f"{number:.{digits}f}"


def _fmt_ci(value: Any, ci: list[Any] | None) -> str:
    if value is None:
        return "—"
    if not ci or ci[0] is None or ci[1] is None:
        return _fmt(value)
    return f'{_fmt(value)} <span class="muted">({_fmt(ci[0])}–{_fmt(ci[1])})</span>'


def _embed_png(path: Path, heading: str, alt: str, note: str = "", wide: bool = False) -> str:
    if not path.exists():
        return ""
    encoded = base64.b64encode(path.read_bytes()).decode("ascii")
    note_html = f'<p class="diagram-label">{note}</p>' if note else ""
    panel_class = "panel wide" if wide else "panel"
    return (f'<div class="{panel_class}"><h3>{html.escape(heading)}</h3>'
            f'<img alt="{html.escape(alt)}" src="data:image/png;base64,{encoded}">{note_html}</div>')


def _join_names(names: list[str]) -> str:
    return names[0] if len(names) == 1 else ", ".join(names[:-1]) + " and " + names[-1]


def _render_effective(output: Path, evaluation: dict[str, Any]) -> str:
    """Head-to-head comparison of models for effective prediction."""
    rows = evaluation.get("models", [])
    if not rows:
        return '<p class="empty">Train at least one model to generate the comparison.</p>'
    target = float(evaluation.get("target_sensitivity", 0.8))
    positives = int(evaluation.get("positives", 0))
    prevalence = float(evaluation.get("prevalence", 0.0))
    best = rows[0]

    # Plain-language verdict.
    lines = [
        f'<p><strong>{html.escape(model_label(best["model"]))}</strong> ranks first on AUPRC '
        f'({_fmt(best["auprc"])}, {_fmt(best.get("auprc_lift"), 1)}× the {prevalence:.1%} base rate) '
        f'with AUROC {_fmt(best["auroc"])}.</p>'
    ]
    if len(rows) > 1:
        compared = [r for r in rows[1:] if r.get("vs_best")]
        both = [model_label(r["model"]) for r in compared
                if r["vs_best"]["distinguishable"] and r["vs_best"].get("auroc_distinguishable")]
        auprc_only = [model_label(r["model"]) for r in compared
                      if r["vs_best"]["distinguishable"] and not r["vs_best"].get("auroc_distinguishable")]
        close = [model_label(r["model"]) for r in compared if not r["vs_best"]["distinguishable"]]
        if both:
            lines.append(f'<p>It is better than {html.escape(_join_names(both))} on both AUPRC and AUROC, '
                         'beyond resampling noise.</p>')
        if auprc_only:
            lines.append(f'<p>Against {html.escape(_join_names(auprc_only))} its AUPRC advantage exceeds resampling noise '
                         'but AUROC does not separate them, so the gain is in precision among the highest-risk patients '
                         'rather than in overall ranking.</p>')
        if close:
            lines.append(f'<p>It cannot be separated from {html.escape(_join_names(close))}: the 95% interval for the '
                         'AUPRC difference includes zero, so treat these as equivalent on this test set.</p>')
    op = best.get("operating_point", {})
    if op.get("threshold") is not None:
        lines.append(
            f'<p>At {target:.0%} sensitivity it raises {_fmt(op.get("alerts_per_100"), 1)} alerts per 100 patients, '
            f'about {_fmt(op.get("alerts_per_true_case"), 1)} alerts for every true future case, '
            f'and misses {_fmt(op.get("missed_per_100"), 1)} cases per 100 patients.</p>'
        )
    if positives < 30:
        lines.append(f'<p class="caution">Only {positives} positive patients are in the test set. '
                     'Intervals are wide and rankings may change with a different split.</p>')
    verdict = '<div class="verdict">' + "".join(lines) + "</div>"

    # Ranking table.
    header = ("<tr><th>Rank</th><th>Model</th><th>AUPRC (95% CI)</th><th>AUROC (95% CI)</th><th>Brier</th>"
              "<th>Calibration slope</th>"
              f"<th>Specificity at {target:.0%} sens.</th><th>PPV</th><th>Alerts / 100</th>"
              "<th>Alerts per true case</th><th>Versus top model</th></tr>")
    body = []
    for row in rows:
        op = row.get("operating_point", {})
        cal = row.get("calibration", {})
        vs = row.get("vs_best")
        if vs is None:
            versus = "Top ranked" if row["rank"] == 1 else "—"
        else:
            share = vs.get("share_of_resamples_best_wins")
            if vs["distinguishable"] and vs.get("auroc_distinguishable"):
                verdict_text = "Worse on AUPRC and AUROC"
            elif vs["distinguishable"]:
                verdict_text = "Worse on AUPRC only"
            else:
                verdict_text = "Not separable"
            versus = verdict_text + (
                f'; top wins {share:.0%} of resamples' if share is not None else "")
        body.append(
            "<tr>"
            f'<td>{row["rank"]}</td>'
            f'<td><span class="swatch" style="background:{model_color(row["model"])}"></span>{html.escape(model_label(row["model"]))}</td>'
            f'<td>{_fmt_ci(row["auprc"], row.get("auprc_ci"))}</td>'
            f'<td>{_fmt_ci(row["auroc"], row.get("auroc_ci"))}</td>'
            f'<td>{_fmt(row["brier"])}</td>'
            f'<td>{_fmt(cal.get("calibration_slope"), 2)}</td>'
            f'<td>{_fmt(op.get("specificity"))}</td>'
            f'<td>{_fmt(op.get("ppv"))}</td>'
            f'<td>{_fmt(op.get("alerts_per_100"), 1)}</td>'
            f'<td>{_fmt(op.get("alerts_per_true_case"), 1)}</td>'
            f"<td>{html.escape(versus)}</td>"
            "</tr>"
        )
    table = ('<h3>Head-to-head ranking</h3><div class="table-wrap"><table class="rank-table">'
             f"<thead>{header}</thead><tbody>{''.join(body)}</tbody></table></div>"
             f'<p class="diagram-label">Ranked by AUPRC, the more informative discrimination metric when sepsis is rare; '
             f'AUROC breaks ties. Intervals are paired percentile bootstraps over the same test patients '
             f'({evaluation.get("n_bootstrap", "—")} resamples). Operating-point columns use, for each model, the highest '
             f'threshold reaching {target:.0%} sensitivity on these test patients, so models are compared at matched sensitivity; '
             'because that threshold is chosen on the test set it describes the models rather than predicting deployed performance. '
             'A calibration slope near 1 means predicted risks are neither over- nor under-confident.</p>')

    charts = "".join([
        _embed_png(output / "model_forest.png", "Discrimination with uncertainty", "Forest plot of AUPRC and AUROC with 95% intervals", wide=True),
        _embed_png(output / "calibration.png", "Calibration", "Calibration curves by model",
                   "Points below the diagonal mean the model over-states risk. Class-weighted models are expected to sit below it."),
        _embed_png(output / "decision_curve.png", "Clinical utility", "Decision curve net benefit by model",
                   "Net benefit counts true alerts minus false alerts, weighted by how many false alerts are acceptable per true one at each threshold. A model is only useful where its curve sits above both reference lines."),
    ])
    return verdict + table + f'<div class="chart-grid" style="margin-top:16px">{charts}</div>'


def _render_methodology(
    config: dict[str, Any],
    cohort: dict[str, Any],
    evaluation: dict[str, Any],
    features: pd.DataFrame | None,
) -> str:
    if not config:
        return ""
    specs = config.get("model_specs", {})
    n_features = features.shape[1] if features is not None else len(KNOWN_CLINICAL_COLUMNS) * 8
    exclusions = cohort.get("exclusions", {})
    excluded_text = ", ".join(f"{v} {k.replace('_', ' ')}" for k, v in exclusions.items()) or "none recorded"
    model_rows = "".join(
        "<tr>"
        f'<td><span class="swatch" style="background:{model_color(name)}"></span>{html.escape(model_label(name))}</td>'
        f'<td>{html.escape(spec.get("input", "—"))}</td>'
        f'<td>{html.escape("; ".join(spec.get("preprocessing", [])))}</td>'
        f'<td style="white-space:normal;min-width:260px">{html.escape(spec.get("estimator", "—"))}</td>'
        f'<td>{html.escape(spec.get("class_weighting", "—"))}</td>'
        "</tr>"
        for name, spec in specs.items()
    )
    target = float(evaluation.get("target_sensitivity", 0.8)) if evaluation else 0.8
    return f'''<section><h2>Methodology</h2><div class="method-grid prose">
<div><h3>Data and cohort</h3>
<p>Source data are hourly ICU records from the PhysioNet/Computing in Cardiology Challenge 2019, one pipe-separated file per patient. Rows are read in file order as consecutive ICU hours.</p>
<p>Each patient contributes one prediction made at the end of hour 5. Inputs are rows 0–5 only. The outcome is any positive SepsisLabel from row 6 onward. In this dataset the label is already shifted to switch on six hours before the Sepsis-3 onset time, so a positive outcome corresponds to onset at roughly hour 12 or later, and patients with earlier onset are excluded as already labelled in the look-back.</p>
<p>Eligible patients: {html.escape(str(cohort.get("eligible_patients", "—")))}, of whom {html.escape(str(cohort.get("positive_outcomes", "—")))} have a positive outcome. Excluded: {html.escape(excluded_text)}.</p>
<p>The outcome window runs to the end of each record, so it is longer for patients who stay longer. See the improvement plan for a fixed-horizon alternative.</p></div>
<div><h3>Features and representations</h3>
<p>Tabular models receive {n_features} engineered features: for each of {len(KNOWN_CLINICAL_COLUMNS)} clinical and demographic variables, the latest observed value, mean, minimum, maximum, standard deviation, first-to-last change, fraction of hours missing, and an any-missing flag.</p>
<p>The 1D CNN receives the same six hours as an ordered hours × variables tensor without summary statistics or missingness flags. A difference between the CNN and the tabular models therefore reflects both the representation and the model family.</p>
<p>SepsisLabel, the patient identifier and ICULOS are never inputs.</p></div>
<div><h3>Splitting and preprocessing</h3>
<p>Patients are split once into training ({html.escape(str(config.get("n_train", "—")))}) and held-out test ({html.escape(str(config.get("n_test", "—")))}) groups with seed {html.escape(str(config.get("random_state", "—")))} and test fraction {html.escape(str(config.get("test_size", "—")))}. Every model is scored on the same test patients.</p>
<p>Imputation and scaling are learned from training patients only and then applied unchanged to test patients. No hyperparameters were tuned, and no validation split was used.</p></div>
<div><h3>Evaluation</h3>
<p>Models are ranked by AUPRC, with AUROC as a tie-break. Uncertainty comes from {html.escape(str(evaluation.get("n_bootstrap", 1000)))} paired bootstrap resamples of the test patients. A model is called worse than the top model only when the 95% interval of the AUPRC difference excludes zero.</p>
<p>To compare alert burden fairly, each model is also read at the threshold that reaches {target:.0%} sensitivity, reporting specificity, PPV and alerts per 100 patients. Calibration is summarised by the logistic calibration slope and a 10-bin calibration curve, and clinical utility by decision-curve net benefit across alert thresholds from 1% to 50%.</p></div>
</div>
<h3 style="margin-top:12px">Models compared</h3><div class="table-wrap"><table><thead><tr><th>Model</th><th>Input</th><th>Preprocessing</th><th>Estimator</th><th>Class weighting</th></tr></thead><tbody>{model_rows}</tbody></table></div>
<p class="diagram-label">This is a retrospective, single-split educational analysis. It is not validated for clinical use.</p></section>'''


ALL_MODELS = ("logistic_regression", "random_forest", "xgboost", "cnn_1d")
DEFAULT_LANE_TEXT = {
    "logistic_regression": (["Median impute", "Standardise"], "L2, balanced weights"),
    "random_forest": (["Median impute"], "300 trees, balanced"),
    "xgboost": (["Median impute"], "300 trees, depth 4, unweighted"),
    "cnn_1d": (["Variable median impute", "Variable z-score"], "2 conv layers, pos_weight"),
}


def _svg_box(x: float, y: float, w: float, h: float, lines: list[str], *, fill: str, stroke: str,
             bold_first: bool = False, dashed: bool = False, text_color: str = "#1c2727", size: int = 13) -> str:
    dash = ' stroke-dasharray="6 4"' if dashed else ""
    parts = [f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="5" fill="{fill}" stroke="{stroke}" stroke-width="2"{dash}/>']
    line_height = size + 5
    start = y + h / 2 - (len(lines) - 1) * line_height / 2 + size * 0.35
    for index, line in enumerate(lines):
        weight = ' font-weight="700"' if bold_first and index == 0 else ""
        parts.append(f'<text x="{x + w / 2}" y="{start + index * line_height:.1f}" fill="{text_color}" font-size="{size}"{weight}>{html.escape(line)}</text>')
    return "".join(parts)


def _render_diagrams(config: dict[str, Any]) -> str:
    design = config.get("design", {})
    run_models = set(config.get("models", []))
    lane_top, lane_h, lane_gap = 44, 66, 24
    lane_y = {name: lane_top + i * (lane_h + lane_gap) for i, name in enumerate(ALL_MODELS)}
    lanes_bottom = lane_y["cnn_1d"] + lane_h
    shared_y, shared_h = lane_top + 70, lanes_bottom - lane_top - 140
    arrow = 'fill="none" stroke="#536966" stroke-width="2" marker-end="url(#arrowL)"'

    parts = [
        '<defs><marker id="arrowL" markerWidth="9" markerHeight="9" refX="7" refY="4.5" orient="auto">'
        '<path d="M0,0 L9,4.5 L0,9 z" fill="#536966"/></marker></defs>',
        '<g font-family="Segoe UI, sans-serif" text-anchor="middle">',
        # column captions
        '<g fill="#52605f" font-size="12">'
        '<text x="80" y="24">Ingest</text><text x="240" y="24">Cohort</text><text x="400" y="24">Split</text>'
        '<text x="570" y="24">Representation</text><text x="757" y="24">Train-only preprocessing</text>'
        '<text x="955" y="24">Estimator</text><text x="1135" y="24">Evaluate</text></g>',
        _svg_box(16, shared_y, 128, shared_h, ["Patient PSV", "files", "", "40 variables", "+ SepsisLabel"],
                 fill="#eef2ed", stroke="#8b9a91"),
        _svg_box(172, shared_y, 136, shared_h, ["Eligibility", "", "Inputs: rows 0–5", "Outcome: row 6+", "", "1 row per patient"],
                 fill="#e4f1ed", stroke="#167b73"),
        _svg_box(336, shared_y, 128, shared_h, ["Patient-level", "split", "", f"seed {config.get('random_state', '—')}",
                                                f"test {config.get('test_size', '—')}"], fill="#fff0d9", stroke="#d89a38"),
        f'<path d="M144 {lanes_bottom / 2 + lane_top / 2} H164" {arrow}/>',
        f'<path d="M308 {lanes_bottom / 2 + lane_top / 2} H328" {arrow}/>',
    ]
    # representation boxes
    tab_top, tab_bottom = lane_y["logistic_regression"], lane_y["xgboost"] + lane_h
    parts.append(_svg_box(500, tab_top, 140, tab_bottom - tab_top,
                          ["Tabular features", "", "8 summaries per", "variable over", "hours 0–5,", "incl. missingness"],
                          fill="#f3f6f4", stroke="#536966"))
    parts.append(_svg_box(500, lane_y["cnn_1d"], 140, lane_h, ["Ordered tensor", "6 h × variables"],
                          fill="#f3f6f4", stroke="#536966",
                          dashed="cnn_1d" not in run_models))
    split_mid = lanes_bottom / 2 + lane_top / 2
    parts.append(f'<path d="M464 {split_mid} C480 {split_mid} 478 {(tab_top + tab_bottom) / 2} 492 {(tab_top + tab_bottom) / 2}" {arrow}/>')
    cnn_mid = lane_y["cnn_1d"] + lane_h / 2
    parts.append(f'<path d="M464 {split_mid} C482 {split_mid} 478 {cnn_mid} 492 {cnn_mid}" {arrow}/>')

    specs = config.get("model_specs", {})
    for name in ALL_MODELS:
        y = lane_y[name]
        mid = y + lane_h / 2
        active = name in run_models
        color = model_color(name) if active else "#a9b3b0"
        fill = "#ffffff" if active else "#f6f7f5"
        text_color = "#1c2727" if active else "#8c9794"
        prep, est = DEFAULT_LANE_TEXT[name]
        if name in specs and specs[name].get("preprocessing"):
            prep = [p.split(" (")[0].capitalize() for p in specs[name]["preprocessing"]][:2]
        parts.append(_svg_box(672, y, 170, lane_h, prep, fill=fill, stroke=color, dashed=not active,
                              text_color=text_color, size=12))
        label = model_label(name) + ("" if active else " (not run)")
        parts.append(_svg_box(870, y, 170, lane_h, [label, est], fill=fill, stroke=color, bold_first=True,
                              dashed=not active, text_color=text_color, size=12))
        parts.append(f'<rect x="870" y="{y}" width="6" height="{lane_h}" fill="{color}"/>')
        source_x = 640
        parts.append(f'<path d="M{source_x} {mid} H664" {arrow}/>')
        parts.append(f'<path d="M842 {mid} H862" {arrow}/>')
        parts.append(f'<path d="M1040 {mid} C1056 {mid} 1052 {split_mid} 1068 {split_mid}" {arrow}/>')

    parts.append(_svg_box(1076, shared_y, 118, shared_h,
                          ["Same test", "patients", "", "Bootstrap CIs", "Matched", "sensitivity", "Calibration", "Net benefit"],
                          fill="#e9e6f0", stroke="#745d92", size=12))
    parts.append(f'<text x="605" y="{lanes_bottom + 30}" fill="#52605f" font-size="12">'
                 'Solid lanes ran in this experiment; dashed lanes are available but were not selected. '
                 'Every learned step is fitted on training patients only.</text>')
    parts.append("</g>")
    height = lanes_bottom + 46
    pipeline = (f'<div class="diagram"><p class="diagram-label">Model pipeline: shared cohort and split, one lane per model, '
                f'shared held-out evaluation</p><svg viewBox="0 0 1210 {height}" role="img" '
                f'aria-label="Model pipeline with one lane per model">{"".join(parts)}</svg></div>')

    lineage = '''<div class="diagram"><p class="diagram-label">Data lineage: predictors and target come from disjoint time ranges</p><svg viewBox="0 0 1040 200" role="img" aria-label="Data lineage diagram"><defs><marker id="arrow2" markerWidth="9" markerHeight="9" refX="7" refY="4.5" orient="auto"><path d="M0,0 L9,4.5 L0,9 z" fill="#536966"/></marker></defs><g font-family="Segoe UI, sans-serif" font-size="13" text-anchor="middle"><rect x="24" y="48" width="190" height="78" rx="5" fill="#eef2ed" stroke="#8b9a91"/><text x="119" y="78" fill="#1c2727"><tspan>Raw patient file</tspan><tspan x="119" dy="20">values + labels</tspan></text><rect x="300" y="24" width="235" height="66" rx="5" fill="#e4f1ed" stroke="#167b73" stroke-width="2"/><text x="417" y="51" fill="#1c2727"><tspan>Rows 0–5</tspan><tspan x="417" dy="19">clinical inputs only</tspan></text><rect x="300" y="108" width="235" height="58" rx="5" fill="#fbebe7" stroke="#c45042" stroke-width="2"/><text x="417" y="132" fill="#1c2727"><tspan>Row 6 onward</tspan><tspan x="417" dy="18">outcome labels only</tspan></text><rect x="642" y="48" width="174" height="78" rx="5" fill="#fff0d9" stroke="#d89a38" stroke-width="2"/><text x="729" y="78" fill="#1c2727"><tspan>Join by patient</tspan><tspan x="729" dy="20">after eligibility</tspan></text><rect x="880" y="48" width="142" height="78" rx="5" fill="#e9e6f0" stroke="#745d92" stroke-width="2"/><text x="951" y="78" fill="#1c2727"><tspan>Saved test</tspan><tspan x="951" dy="20">predictions</tspan></text><path d="M215 86 H290 M535 56 C580 56 590 70 632 80 M535 137 C580 137 590 105 632 94 M817 86 H870" fill="none" stroke="#536966" stroke-width="2" marker-end="url(#arrow2)"/><text x="520" y="186" fill="#52605f">Patient ID is lineage metadata, never an input. SepsisLabel switches on 6 h before Sepsis-3 onset and is target-only.</text></g></svg></div>'''
    metadata = (f'<p class="diagram-label">Recorded design: {html.escape(str(design.get("lookback_hours", "six-hour look-back")))}; '
                f'outcome: {html.escape(str(design.get("prediction_period", "post-look-back label")))}; '
                f'split unit: {html.escape(str(design.get("split_unit", "patient")))}.</p>')
    return pipeline + lineage + metadata


def _render_sample(
    records: list[PatientRecord] | None,
    features: pd.DataFrame | None,
) -> str:
    if not records:
        return '<p class="empty">Source rows are unavailable for this report. Generate it through the `run` or `eda` command to include a sample.</p>'
    if features is not None:
        eligible_ids = set(features.index.astype(str))
        records = [record for record in records if record.patient_id in eligible_ids]
    records = records[:5]
    if not records:
        return '<p class="empty">No eligible source observations are available for the sample.</p>'
    sample_columns = [column for column in ("HR", "O2Sat", "Temp", "SBP", "MAP", "Resp", TARGET_COLUMN) if any(column in record.frame.columns for record in records)]
    rows = []
    for patient_number, record in enumerate(records[:3], start=1):
        for hour, (_, row) in enumerate(record.frame.head(6).iterrows()):
            values = [f"Sample {patient_number}", str(hour)]
            values.extend(_format_value(row.get(column)) for column in sample_columns)
            rows.append(values)
    if not rows:
        return '<p class="empty">No input observations were available.</p>'
    headers = ["Sample patient", "Hour index", *sample_columns]
    table = pd.DataFrame(rows, columns=headers)
    return '<div class="table-wrap">' + table.to_html(index=False, escape=True, border=0) + '</div>'


def _render_feature_sample(features: pd.DataFrame | None) -> str:
    if features is None or features.empty:
        return '<p class="empty">Engineered features are unavailable for this report.</p>'
    preferred = [column for column in ("HR_latest", "HR_mean", "HR_delta", "HR_missing_fraction", "O2Sat_latest", "Temp_latest", "MAP_latest") if column in features.columns]
    sample = features.loc[:, preferred].head(5).copy()
    sample.insert(0, "sample_patient", [f"Sample {index}" for index in range(1, len(sample) + 1)])
    sample = sample.apply(lambda column: column.map(_format_value))
    return '<div class="table-wrap">' + sample.to_html(index=False, escape=True, border=0) + '</div>'


def _format_value(value: Any) -> str:
    if value is None or pd.isna(value):
        return "—"
    try:
        number = float(value)
    except (TypeError, ValueError):
        return html.escape(str(value))
    if number.is_integer():
        return str(int(number))
    return f"{number:.3g}"