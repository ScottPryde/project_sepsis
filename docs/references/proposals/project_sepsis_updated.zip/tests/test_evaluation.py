import json

import numpy as np
import pandas as pd

from sepsis_prediction.evaluation import compare_models, operating_point


def _write_predictions(directory, n=400, seed=0):
    rng = np.random.default_rng(seed)
    y = (rng.random(n) < 0.15).astype(int)
    strong = np.clip(0.15 + 0.5 * y + rng.normal(0, 0.15, n), 0, 1)
    weak = np.clip(0.15 + 0.05 * y + rng.normal(0, 0.15, n), 0, 1)
    pd.DataFrame({
        "patient_id": [f"p{i}" for i in range(n)],
        "y_true": y,
        "logistic_regression_probability": weak,
        "xgboost_probability": strong,
    }).to_csv(directory / "test_predictions.csv", index=False)
    return y, strong


def test_compare_models_ranks_separates_and_writes_artifacts(tmp_path) -> None:
    _write_predictions(tmp_path)
    result = compare_models(tmp_path, n_bootstrap=200, random_state=3)

    assert result["best_model"] == "xgboost"
    ranked = {row["model"]: row for row in result["models"]}
    assert ranked["xgboost"]["rank"] == 1
    weaker = ranked["logistic_regression"]["vs_best"]
    assert weaker["distinguishable"] is True
    low, high = ranked["xgboost"]["auprc_ci"]
    assert low <= ranked["xgboost"]["auprc"] <= high
    assert len(result["decision_curve"]["thresholds"]) == len(result["decision_curve"]["models"]["xgboost"])
    for name in ("model_evaluation.json", "model_ranking.csv", "calibration.png", "decision_curve.png", "model_forest.png"):
        assert (tmp_path / name).is_file()
    json.loads((tmp_path / "model_evaluation.json").read_text(encoding="utf-8"))


def test_compare_models_is_reproducible_for_a_fixed_seed(tmp_path) -> None:
    _write_predictions(tmp_path)
    first = compare_models(tmp_path, n_bootstrap=100, random_state=5)
    second = compare_models(tmp_path, n_bootstrap=100, random_state=5)
    assert first["models"] == second["models"]


def test_operating_point_reaches_target_sensitivity(tmp_path) -> None:
    y, strong = _write_predictions(tmp_path)
    point = operating_point(y, strong, 0.8)
    assert point["sensitivity"] >= 0.8
    assert 0 <= point["specificity"] <= 1
    assert point["alerts_per_100"] >= point["true_alerts_per_100"]


def test_operating_point_is_empty_without_both_classes() -> None:
    assert operating_point(np.zeros(10, dtype=int), np.linspace(0, 1, 10), 0.8) == {"threshold": None}
